// Presentation State
let currentSlide = 1;
const totalSlides = 13;

// Navigation Elements
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const currentSlideSpan = document.getElementById('currentSlide');
const totalSlidesSpan = document.getElementById('totalSlides');

// Initialize
function init() {
  totalSlidesSpan.textContent = totalSlides;
  updateSlide();
  createCharts();
}

// Update Slide Display
function updateSlide() {
  const slides = document.querySelectorAll('.slide');
  
  slides.forEach((slide, index) => {
    slide.classList.remove('active', 'prev');
    if (index + 1 === currentSlide) {
      slide.classList.add('active');
    } else if (index + 1 < currentSlide) {
      slide.classList.add('prev');
    }
  });
  
  currentSlideSpan.textContent = currentSlide;
  
  // Update button states
  prevBtn.disabled = currentSlide === 1;
  nextBtn.disabled = currentSlide === totalSlides;
}

// Navigate to specific slide
function goToSlide(slideNumber) {
  if (slideNumber >= 1 && slideNumber <= totalSlides) {
    currentSlide = slideNumber;
    updateSlide();
  }
}

// Next slide
function nextSlide() {
  if (currentSlide < totalSlides) {
    currentSlide++;
    updateSlide();
  }
}

// Previous slide
function prevSlide() {
  if (currentSlide > 1) {
    currentSlide--;
    updateSlide();
  }
}

// Event Listeners
prevBtn.addEventListener('click', prevSlide);
nextBtn.addEventListener('click', nextSlide);

// Keyboard Navigation
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowRight' || e.key === 'PageDown') {
    nextSlide();
  } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
    prevSlide();
  } else if (e.key === 'Home') {
    goToSlide(1);
  } else if (e.key === 'End') {
    goToSlide(totalSlides);
  }
});

// Create Charts
function createCharts() {
  // Chart colors
  const chartColors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F'];
  
  // Position Chart (Slide 4)
  const positionCtx = document.getElementById('positionChart');
  if (positionCtx) {
    new Chart(positionCtx, {
      type: 'bar',
      data: {
        labels: ['Position 1', 'Position 2', 'Position 3', 'Position 4', 'Position 5'],
        datasets: [
          {
            label: 'Unique Rules',
            data: [2, 3, 4, 4, 4],
            backgroundColor: chartColors[0],
            borderWidth: 0
          },
          {
            label: 'Diversity Index (%)',
            data: [40, 60, 80, 80, 80],
            backgroundColor: chartColors[1],
            borderWidth: 0,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: {
              color: '#f5f5f5',
              font: { size: 14 }
            }
          },
          title: {
            display: true,
            text: 'Position-Dependent Compatibility Analysis',
            color: '#32b8c6',
            font: { size: 16, weight: 'bold' }
          }
        },
        scales: {
          x: {
            ticks: { color: '#f5f5f5' },
            grid: { color: 'rgba(167, 169, 169, 0.1)' }
          },
          y: {
            position: 'left',
            ticks: { color: '#f5f5f5' },
            grid: { color: 'rgba(167, 169, 169, 0.1)' },
            title: {
              display: true,
              text: 'Unique Rules',
              color: '#f5f5f5'
            }
          },
          y1: {
            position: 'right',
            ticks: { color: '#f5f5f5' },
            grid: { display: false },
            title: {
              display: true,
              text: 'Diversity (%)',
              color: '#f5f5f5'
            }
          }
        }
      }
    });
  }
  
  // Scale Chart (Slide 6)
  const scaleCtx = document.getElementById('scaleChart');
  if (scaleCtx) {
    new Chart(scaleCtx, {
      type: 'line',
      data: {
        labels: ['N=4', 'N=5', 'N=6', 'N=7', 'N=8'],
        datasets: [
          {
            label: 'Rule 30',
            data: [1, 0, 1, 1, 1],
            borderColor: chartColors[0],
            backgroundColor: chartColors[0],
            tension: 0.3,
            pointRadius: 6
          },
          {
            label: 'Rule 45',
            data: [0, 0, 1, 1, 0],
            borderColor: chartColors[1],
            backgroundColor: chartColors[1],
            tension: 0.3,
            pointRadius: 6
          },
          {
            label: 'Rule 75',
            data: [1, 1, 1, 0, 0],
            borderColor: chartColors[2],
            backgroundColor: chartColors[2],
            tension: 0.3,
            pointRadius: 6
          },
          {
            label: 'Rule 210',
            data: [1, 1, 1, 1, 0],
            borderColor: chartColors[3],
            backgroundColor: chartColors[3],
            tension: 0.3,
            pointRadius: 6
          },
          {
            label: 'Rule 225',
            data: [1, 0, 1, 1, 1],
            borderColor: chartColors[4],
            backgroundColor: chartColors[4],
            tension: 0.3,
            pointRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: {
              color: '#f5f5f5',
              font: { size: 14 }
            }
          },
          title: {
            display: true,
            text: 'Rule Availability Across System Scales',
            color: '#32b8c6',
            font: { size: 16, weight: 'bold' }
          }
        },
        scales: {
          x: {
            ticks: { color: '#f5f5f5' },
            grid: { color: 'rgba(167, 169, 169, 0.1)' }
          },
          y: {
            ticks: { 
              color: '#f5f5f5',
              stepSize: 1,
              callback: function(value) {
                return value === 1 ? 'Available' : 'Not Available';
              }
            },
            grid: { color: 'rgba(167, 169, 169, 0.1)' },
            min: 0,
            max: 1
          }
        }
      }
    });
  }
  
  // Yield Chart (Slide 8)
  const yieldCtx = document.getElementById('yieldChart');
  if (yieldCtx) {
    new Chart(yieldCtx, {
      type: 'bar',
      data: {
        labels: ['N=4', 'N=5', 'N=6', 'N=7', 'N=8'],
        datasets: [
          {
            label: 'Yield per Configuration',
            data: [2.0, 2.0, 3.33, 6.5, 2.0],
            backgroundColor: chartColors.map((color, i) => i === 3 ? color : 'rgba(50, 184, 198, 0.5)'),
            borderWidth: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: {
              color: '#f5f5f5',
              font: { size: 14 }
            }
          },
          title: {
            display: true,
            text: 'Configuration Productivity Across Scales',
            color: '#32b8c6',
            font: { size: 16, weight: 'bold' }
          }
        },
        scales: {
          x: {
            ticks: { color: '#f5f5f5' },
            grid: { color: 'rgba(167, 169, 169, 0.1)' }
          },
          y: {
            ticks: { color: '#f5f5f5' },
            grid: { color: 'rgba(167, 169, 169, 0.1)' },
            title: {
              display: true,
              text: 'Yield per Config',
              color: '#f5f5f5'
            }
          }
        }
      }
    });
  }
  
  // Dominance Chart (Slide 9)
  const dominanceCtx = document.getElementById('dominanceChart');
  if (dominanceCtx) {
    new Chart(dominanceCtx, {
      type: 'doughnut',
      data: {
        labels: ['Rule 30', 'Rule 45', 'Rule 225', 'Rule 210', 'Rule 75'],
        datasets: [{
          data: [37.88, 25.76, 15.15, 13.64, 7.58],
          backgroundColor: chartColors,
          borderWidth: 2,
          borderColor: '#262828'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: {
              color: '#f5f5f5',
              font: { size: 14 },
              padding: 15
            }
          },
          title: {
            display: true,
            text: 'Rule Utilization Distribution',
            color: '#32b8c6',
            font: { size: 16, weight: 'bold' }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return context.label + ': ' + context.parsed + '%';
              }
            }
          }
        }
      }
    });
  }
}

// Initialize on load
window.addEventListener('DOMContentLoaded', init);